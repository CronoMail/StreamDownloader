"""
Stream Downloader - A modern UI application for downloading Twitch and YouTube livestreams
"""

__version__ = '1.0.0'
